<?php
$dbhost="localhost";
$dbname="mocktest";
$dbuser="postgres";
$con=pg_connect("host=127.0.0.1 dbname=mocktest user=postgres password=123")or die(pg_last_error());
if($con!=NULL)
{
 //echo"connected";
}
else
 {
 // echo"not";
 }
?>
