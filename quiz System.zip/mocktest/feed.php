<?php
include_once 'dbConnection.php';
echo $ref=@$_GET['q'];
echo $name = $_POST['name'];
echo $email = $_POST['email'];
echo $subject = $_POST['subject'];
echo $id=mt_rand();
echo $feedback = $_POST['feedback'];
echo $q=pg_query($con,"INSERT INTO feedback VALUES('$id','$name','$email' ,'$subject','$feedback')");
header("location:$ref?q=Thank you for your valuable feedback");
?>
